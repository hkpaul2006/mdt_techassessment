﻿using System;
using System.IO;

namespace TechAssessment1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                StreamReader r = new StreamReader("data.json");
                string json = r.ReadToEnd();

                var data = Newtonsoft.Json.JsonConvert.DeserializeObject<TechData>(json);

                data.StartGenerators();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
