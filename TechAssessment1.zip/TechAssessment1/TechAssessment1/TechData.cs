﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace TechAssessment1
{
    public class TechData
    {
        public List<double[]> datasets { get; set; }
        public List<Generator> generators { get; set; }

        public void StartGenerators()
        {
            foreach (var item in generators)
            {
                item.datasets = datasets;
                item.StartGen();
            }
        }
    }

    public class Generator
    {
        public List<double[]> datasets { get; set; }

        public string name { get; set; }
        public int interval { get; set; }
        public string operation { get; set; }

        public void StartGen()
        {
            Console.WriteLine("{0} Starting {1}...", DateTime.Now, this.name);
            Thread t = new Thread(PrintResult);
            t.Name = this.name;
            t.Start();

        }
        public void PrintResult()
        {
            foreach (var item in datasets)
            {
                switch (operation.ToLower())
                {
                    case "sum":
                        Console.WriteLine("{0} {1} {2}", DateTime.Now, this.name, Math.Round(item.Sum(), 2));
                        break;
                    case "average":
                        Console.WriteLine("{0} {1} {2}", DateTime.Now, this.name, Math.Round(item.Average(), 2));
                        break;
                    case "min":
                        Console.WriteLine("{0} {1} {2}", DateTime.Now, this.name, Math.Round(item.Min(), 2));
                        break;
                    case "max":
                        Console.WriteLine("{0} {1} {2}", DateTime.Now, this.name, Math.Round(item.Max(), 2));
                        break;
                    default:
                        Console.WriteLine("{0} {1} INVALID OPERATION {2}", DateTime.Now, this.name, operation);
                        break;

                }
                Thread.Sleep(this.interval * 1000);
            }
        }
    }
}
