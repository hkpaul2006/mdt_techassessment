﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TechAssessmentS2.Models
{
    public class TechData
    {
        public List<double[]> Datasets { get; set; }
        public List<Generator> Generators { get; set; }

        public void StartGenerators()
        {
            foreach (var item in Generators)
            {
                item.datasets = Datasets;
                item.StartGen();
            }
        }
    }
}
