﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace TechAssessmentS2.Models
{
    public class Generator
    {
        public List<double[]> datasets { get; set; }

        public string Name { get; set; }
        public int Interval { get; set; }
        public string Operation { get; set; }
        public string GeneratorOutput { get; set; }

        public string StartGen()
        {
            Console.WriteLine("{0} Starting {1}...", DateTime.Now, this.Name);

            GeneratorOutput = String.Format("{0} Starting {1}...\n", DateTime.Now, this.Name);
            GeneratorOutput += String.Format("Testing on {0}", DateTime.Now);

            
            Thread t = new Thread(PrintResult);
            t.Name = this.Name;
            t.Start();

            return GeneratorOutput;
        }
        public void PrintResult()
        {
            foreach (var item in datasets)
            {
                switch (Name.ToLower())
                {
                    case "sum":
                        //Console.WriteLine("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Sum(), 2));
                        GeneratorOutput += String.Format("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Sum(), 2));
                        break;
                    case "average":
                        //Console.WriteLine("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Average(), 2));
                        GeneratorOutput += String.Format("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Average(), 2));
                        break;
                    case "min":
                        //Console.WriteLine("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Min(), 2));
                        GeneratorOutput += String.Format("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Min(), 2));
                        break;
                    case "max":
                        //Console.WriteLine("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Max(), 2));
                        GeneratorOutput += String.Format("{0} {1} {2}", DateTime.Now, this.Name, Math.Round(item.Max(), 2));
                        break;
                    default:
                        //Console.WriteLine("{0} {1} INVALID OPERATION {2}", DateTime.Now, this.Name, Operation);
                        GeneratorOutput += String.Format("{0} {1} INVALID OPERATION {2}", DateTime.Now, this.Name, Operation);
                        break;

                }
                Thread.Sleep(this.Interval * 1000);
            }
        }
    }
}
