﻿using Newtonsoft.Json;
using System;
using System.IO;
using System.Threading;
using System.Windows;
using TechAssessmentS2.Commands;
using TechAssessmentS2.Models;

namespace TechAssessmentS2
{
    public class MainViewModel : BaseViewModel
    {
        private string jsonFileName;
        private string jsonContent;
        private string generatorOutput;
        private TechData jsonModel;

        public string FileName 
        { 
            get => jsonFileName;
            set
            {
                jsonFileName = value;
                
                OnPropertyChanged();
                GetJsonCommand.RaiseCanExecuteChanged();
            }
        }
        public string JsonContent 
        { 
            get => jsonContent;
            set
            {
                jsonContent = value;
                OnPropertyChanged();
            }
        }
        public string GeneratorOutput
        {
            get => generatorOutput;
            set
            {
                generatorOutput = value;
                OnPropertyChanged();
            }
        }
        public TechData TechDataModel
        {
            get => jsonModel;
            set
            {
                jsonModel = value;
                OnPropertyChanged();
            }
        }

        public DelegateCommand<string> GetJsonCommand { get; set; }
        public DelegateCommand<string> RunGeneratorCommand { get; set; }

        public MainViewModel()
        {
            GetJsonCommand = new DelegateCommand<string>(GetJson, CanGetJson);
            RunGeneratorCommand = new DelegateCommand<string>(RunGenerators, CanGetJson);
            FileName = "data.json";
        }

        private bool CanGetJson(string fileName)
        {
            return true;
        }

        private void GetJson(string fileName)
        {
            try
            {
                StreamReader r = new StreamReader(fileName);
                string json = r.ReadToEnd();

                JsonContent = json;
                TechDataModel = JsonConvert.DeserializeObject<TechData>(json);               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }            
        }

        //this code will move to model for generator as in the console app
        private async void RunGenerators(string test)
        {
            //MessageBox.Show("Start Generators");
            GeneratorOutput = String.Format("{0} Generator output goes here!!!\n", DateTime.Now); 
            
            GeneratorOutput += String.Format("RunGenerators 0 on {0}\n", DateTime.Now);

            //ONLY FOR TESTING - RAN OUT OF TIME TO SUBMIT ASSESSMENT!!
            Thread t = new Thread(PrintResult);
            t.Start();            
           
            //TechDataModel.StartGenerators();
        }

        //tester function to test dynamically populate the textbox
        //the only thing missing is the correct binding to the generator output inside generator model!!!
        private void PrintResult(object obj)
        {
            int i = 0;
            while (i<4)
            {
                i++;
                GeneratorOutput += String.Format("PrintResult {1} on {0}\n", DateTime.Now, i);
                Thread.Sleep(2 * 1000);
            }
           
        }
    }
}
